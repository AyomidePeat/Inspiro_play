class Song {
  final String name;
  final String image;
  final String artist;

  Song({required this.name, required this.image, required this.artist});
  factory Song.fromJson(dynamic json) {
    return Song(
        artist: json['artist'] as String,
        image: json['images'][0]['hostedLargeUrl'] as String,
        name: json['name'] as String);
  }

  static List<Song> songsFromSnapshot(List snapshot) {
    return snapshot.map((data) {
      return Song.fromJson(data);
    }).toList();
  }

  @override
  String toString() {
    return 'Song{song:$name, image:$image, artist:$artist}';
  }
}
