import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:inspiro_play/screens/model/song_model.dart';

class SongApi {
  static Future<List<Song>> getSong() async {
    var uri = Uri.https('https://spotify23.p.rapidapi.com/playlist/',
 'id: 37i9dQZF1DX4Wsb4d7NKfP');
    
     final response = await http.get(uri, headers: {
      "x-rapidapi-Key": "155a7056e3msh1a6d179b80d6b87p163334jsnd37cd9bfad32",
      "x-rapidapi-Host": "spotify23.p.rapidapi.com",
    
    });
     if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON response
    return json.decode(response.body);
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception
    throw Exception('Failed to load playlist');
  }
    //  Map data = jsonDecode(response.body);
    // List _temp = [];
    // for (var i in data[]) {
    //   _temp.add(i['content']['details']);
    // }
    // return Song.songsFromSnapshot(_temp);

  }
}
