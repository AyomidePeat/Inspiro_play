package com.example.inspiro_play

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
